"""Exercise the packaged executable through its authenticated local HTTP interface."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError
from urllib.parse import urlsplit, parse_qs
from urllib.request import Request, urlopen


def main():
    binary = str(Path(sys.argv[1]).resolve())
    with tempfile.TemporaryDirectory(prefix="nexo-desktop-") as tmp:
        process = subprocess.Popen([binary, "--no-open", "--data-dir", tmp],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            deadline = time.monotonic() + 45
            access = Path(tmp) / "access.json"
            while not access.exists():
                if process.poll() is not None:
                    raise AssertionError("Packaged application exited during startup: " + process.stderr.read().decode(errors="replace")[-1000:])
                if time.monotonic() > deadline:
                    raise AssertionError("Desktop startup timed out")
                time.sleep(0.1)
            url = json.loads(access.read_text())["url"]
            parsed = urlsplit(url)
            base = f"http://127.0.0.1:{parsed.port}"
            token = parse_qs(parsed.fragment)["token"][0]
            def request(path, body=None, authenticated=True):
                headers = {"Content-Type": "application/json"}
                if authenticated:
                    headers["X-Nexo-Key"] = token
                data = json.dumps(body).encode() if body is not None else None
                with urlopen(Request(base + path, data=data, headers=headers), timeout=20) as response:
                    return response.read()
            html = request("/").decode()
            assert 'lang="en"' in html and 'id="setup-view"' in html
            assert b"download" in request("/app.js").lower()
            try:
                request("/api/setup", authenticated=False)
                raise AssertionError("Setup endpoint accepted an unauthenticated request")
            except HTTPError as exc:
                assert exc.code == 401
            status = json.loads(request("/api/status"))
            assert status["desktop"] and status["provider"] == "demo"
            result = json.loads(request("/api/chat", {"message": "/calc 24.5 * 40", "language": "en"}))
            assert result["answer"] == "980.0" and result["stats"]["model_calls"] == 0
            docs = json.loads(request("/api/documents"))["documents"]
            assert any(d["title"] == "Nexo starter guide" for d in docs)
            state = json.loads(request("/api/setup"))
            assert state["phase"] == "idle" and not state["ready"]
            request("/api/shutdown", {})
            process.wait(timeout=25)
            assert process.returncode == 0
            print("Packaged executable passed: startup, English setup assets, authentication, calculator, bundled knowledge and clean shutdown.")
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=10)
            process.stderr.close()


if __name__ == "__main__":
    main()
