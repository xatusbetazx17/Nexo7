# Validation record — 0.3.0

## Completed in this development environment

- Core suite: 63 tests completed, 62 passed and one optional PyTorch test skipped because PyTorch was not installed in this build environment. Coverage includes seven new desktop tests for setup failure/success, operation locks, cancellation, bounded progress logs, instance locking and authenticated setup endpoints.
- Demo engineering evaluation: 6 of 6 fixed tasks passed. No model tokens were used. This checks calculation and document retrieval only.
- English UI integration: JSDOM with the real local HTTP server exercised initial setup, missing-Docker feedback, disabled download controls, demo navigation, calculation, document import, literal HTML handling and return to setup. No JavaScript errors were reported. This is a DOM integration test, not a rendered-browser layout review.
- Linux packaged executable: compiled with PyInstaller 6.22.0 and Python 3.12, then executed successfully. Checks covered startup, English setup assets, authenticated endpoints, a calculator response, bundled starter knowledge and clean shutdown. Development host: x86-64 Linux with glibc 2.39. This locally built binary needs compatible system libraries; the CI configuration builds on Ubuntu 22.04 for a different compatibility baseline.
- Windows portable preview: the C launcher was cross-compiled to x86-64 PE with the Windows GUI subsystem. Official embeddable CPython 3.14.7 was included with a pinned SHA-256 archive checksum. File structure and hashes were checked. **The Windows application has not been executed on Windows.**

## Not completed

- Publication to GitHub: browser authentication was rejected by GitHub. No repository or release has been published by this session.
- Native Windows runner execution and native Windows PyInstaller release build.
- A rendered-browser visual check: this browser environment could not open the local application address.
- End-to-end Docker/model inference, GPU acceleration, measured tokens/second, or a live stress test of the RAM ceiling. This environment does not have a Docker daemon or supported GPU available.
- Comparative model benchmarks, multilingual fluency assessment or any clinical evaluation. No model superiority, universal PC compatibility or disease-curing claim is supported by these tests.

## Reproduce

```bash
python -m unittest discover -s tests -v
python scripts/evaluate.py --output reports/evaluation-demo.json
python -m pip install -r requirements-build.txt
python scripts/build_desktop.py
```

Optional UI integration tests need Node.js and `npm install`; run `npm run test:ui`. Tests simulate a missing Docker executable for the setup check. Real model evaluation should be performed separately on target hardware with `evals/multilingual.jsonl` and `scripts/measure_local.py`, including human review of answers.
