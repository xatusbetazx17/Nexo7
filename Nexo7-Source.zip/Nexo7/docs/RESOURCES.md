# Resource policy

All GB figures in this project are decimal bytes. Sixteen GB is 16,000,000,000 bytes, not 16 GiB.

The planner reserves the greater of 2 GB or 20% of host RAM. It selects a model-container budget no larger than 12 GB, 65% of host RAM, available RAM minus that reserve, and 65% of Docker VM memory when applicable. Unknown memory or inadequate free RAM blocks local setup. Config accepts no limit above 16 GB.

| Model profile | Minimum container budget | Model download admission cap |
| --- | ---: | ---: |
| qwen3.5:0.8b | 2.5 GB | 1.5 GB |
| qwen3.5:2b | 4.8 GB | 3.2 GB |
| qwen3.5:4b | 6.0 GB | 4.2 GB |
| qwen3.5:9b | 10.0 GB | 7.5 GB |

These are conservative policy thresholds, not measured performance guarantees. CPU planning stops at 4B. GPU planning can consider 9B; GPU availability is only a hint until the runtime starts. Unsupported acceleration falls back to CPU. An unsuccessful initial model load can fall back to a smaller profile without increasing the limit.

Docker receives identical `--memory` and `--memory-swap` values. Before allocating the model, and before subsequent inference, Nexo validates the container identity, configured limits, local binding, concurrency settings, and actual `memory.max` / `memory.swap.max` values. The latter must equal the configured byte count and zero. The kernel can terminate the model under pressure; Nexo reports failure instead of raising its budget.

The bound covers the model-server container's charged RAM. It excludes host OS memory, the Python application, browser, Docker VM overhead and dedicated GPU VRAM. Shared/unified GPU allocations and driver behavior need platform-specific validation; no whole-system RAM guarantee is made. Container images and accumulated model downloads are not part of the per-model size cap.

Resource measurements and kernel enforcement must still be validated on actual target hardware. This development environment has no Docker daemon or GPU available. The unit suite checks policy and failure handling using fixtures; it is not an end-to-end inference test.
