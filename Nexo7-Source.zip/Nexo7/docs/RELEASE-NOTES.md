Nexo 7 0.3.0 is an early desktop preview of an independent local assistant.

- English interface and first-run setup wizard.
- Hardware checks, model download progress, cancellation and CPU/GPU selection.
- Verified inference-container RAM guard, adaptive smaller model fallback and multilingual response controls.
- Per-user memory, calculator, document retrieval and source-linked PubMed literature lookup.
- Native Windows and Linux portable builds, tested before publishing. Python is bundled; Docker and model downloads are separate prerequisites.

Extract the archive and run Nexo7.exe on Windows or Nexo7 on Linux. See START-HERE.md inside the archive. SHA-256 checksums are included. Binaries are unsigned previews. Automated application tests are not evidence of model superiority or clinical capability.
