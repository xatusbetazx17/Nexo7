"""First-run setup state; every model launch retains the existing RAM guard."""
from dataclasses import asdict, replace
from pathlib import Path
import threading
from .config import Config
from .hardware import detect_hardware, plan_local
from .local_runtime import local_daemon, start_local, stop_local


class SetupController:
    def __init__(self, database):
        self.config = Config(database=str(database))
        self.operation = threading.Lock()
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.thread = None
        self.owns_runtime = False
        self.state = {"phase": "idle", "logs": [], "error": None, "report": None}

    def snapshot(self):
        with self.lock:
            return {**self.state, "logs": list(self.state["logs"]),
                    "ready": self.config.provider == "ollama"}

    def emit(self, text):
        with self.lock:
            self.state["logs"].append(str(text)[-500:])
            self.state["logs"] = self.state["logs"][-80:]

    def check(self, cpu_only=False):
        hardware = detect_hardware()
        report = {"hardware": asdict(hardware), "requirements_ok": False, "plan": None, "error": None}
        try:
            daemon = local_daemon()
            report["plan"] = plan_local(hardware, daemon["MemTotal"], cpu_only)
            report["requirements_ok"] = True
        except ValueError as exc:
            report["error"] = str(exc)
            try:
                report["plan"] = plan_local(hardware, cpu_only=cpu_only)
            except ValueError:
                pass
        with self.lock:
            self.state["report"] = report
        return report

    def start(self, *, cpu_only=False, language="auto"):
        if type(cpu_only) is not bool:
            raise ValueError("cpu_only must be a boolean")
        language = Config(response_language=language).response_language
        if not self.operation.acquire(blocking=False):
            raise ValueError("A setup or chat operation is already running")
        with self.lock:
            if self.config.provider == "ollama":
                self.operation.release()
                raise ValueError("The local model is already ready. Restart Nexo to change hardware settings.")
            self.cancel.clear()
            self.state.update(phase="preparing", logs=[], error=None)
        def work():
            try:
                self.emit("Checking Docker and the available memory budget…")
                config, plan = start_local(self.config.database, cpu_only=cpu_only,
                                          emit=self.emit, cancel=self.cancel)
                with self.lock:
                    self.config = replace(config, response_language=language)
                    self.owns_runtime = True
                    self.state.update(phase="ready", report={"requirements_ok": True, "plan": plan,
                                                             "hardware": plan["hardware"], "error": None})
                self.emit("Local model ready. You can start a conversation.")
            except Exception as exc:
                with self.lock:
                    self.state.update(phase="error", error=str(exc)[:500])
                self.emit("Setup stopped. Demo mode remains available.")
            finally:
                self.operation.release()
        self.thread = threading.Thread(target=work, name="nexo-setup", daemon=True)
        self.thread.start()
        return self.snapshot()

    def close(self):
        self.cancel.set()
        if self.thread:
            self.thread.join()
        if self.owns_runtime:
            stop_local()
            self.owns_runtime = False
