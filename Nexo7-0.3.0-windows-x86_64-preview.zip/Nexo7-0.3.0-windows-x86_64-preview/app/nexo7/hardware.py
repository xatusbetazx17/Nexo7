"""Read-only hardware discovery and conservative planning; sizes are decimal bytes."""
from dataclasses import asdict, dataclass
import ctypes
import os
from pathlib import Path
import platform
import re
import subprocess

GB = 1_000_000_000
ABSOLUTE_RAM_LIMIT = 16 * GB
OPERATING_RAM_LIMIT = 12 * GB


@dataclass(frozen=True)
class Hardware:
    system: str
    machine: str
    total_bytes: int
    available_bytes: int
    cpu_threads: int
    gpu_hint: str = "cpu"
    memory_source: str = "unknown"


@dataclass(frozen=True)
class Profile:
    model: str
    minimum_budget: int
    max_download: int
    context_tokens: int = 8192


# Download size is only an admission check, not an estimate of peak RAM.
PROFILES = (
    Profile("qwen3.5:0.8b", 2_500_000_000, 1_500_000_000, 6144),
    Profile("qwen3.5:2b", 4_800_000_000, 3_200_000_000),
    Profile("qwen3.5:4b", 6_000_000_000, 4_200_000_000),
    Profile("qwen3.5:9b", 10_000_000_000, 7_500_000_000),
)


def _output(args):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=4,
                              check=True).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def linux_memory(proc=Path("/proc"), cgroup=Path("/sys/fs/cgroup")):
    entries = dict(re.findall(r"^(\w+):\s+(\d+)\s+kB", (proc / "meminfo").read_text(), re.M))
    total = int(entries.get("MemTotal", 0)) * 1024
    available = int(entries.get("MemAvailable", 0)) * 1024
    # Account for visible cgroup-v2 ancestors, including a container's namespace root.
    paths = [cgroup]
    try:
        relative = (proc / "self/cgroup").read_text().split("0::", 1)[1].splitlines()[0].lstrip("/")
        current = (cgroup / relative).resolve()
        if current.is_relative_to(cgroup.resolve()):
            paths.extend([current, *current.parents])
    except (OSError, IndexError):
        pass
    for directory in dict.fromkeys(paths):
        if not directory.resolve().is_relative_to(cgroup.resolve()):
            continue
        try:
            limit = (directory / "memory.max").read_text().strip()
            used = int((directory / "memory.current").read_text())
            if limit != "max":
                total = min(total, int(limit))
                available = min(available, max(0, int(limit) - used))
        except (OSError, ValueError):
            pass
    return total, min(total, available)


def detect_hardware(probe_gpu=True):
    system = platform.system()
    total = available = 0
    source = "unknown"
    try:
        if system == "Linux":
            total, available = linux_memory()
            source = "procfs + visible cgroup v2 limits"
        elif system == "Windows":
            class MemoryStatus(ctypes.Structure):
                _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
                    (name, ctypes.c_ulonglong) for name in
                    ("total", "available", "page_total", "page_available", "virtual_total", "virtual_available", "extended")]
            status = MemoryStatus()
            status.length = ctypes.sizeof(status)
            if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                raise OSError("GlobalMemoryStatusEx")
            total, available = int(status.total), int(status.available)
            source = "GlobalMemoryStatusEx"
        elif system == "Darwin":
            total = int(_output(["sysctl", "-n", "hw.memsize"]).strip())
            vm = _output(["vm_stat"])
            page = int(re.search(r"page size of (\d+) bytes", vm).group(1))
            # Exclude speculative/reclaimable estimates: conservative free + inactive.
            available = sum(int(re.search(label + r":\s+(\d+)", vm).group(1))
                            for label in ("Pages free", "Pages inactive")) * page
            source = "sysctl + vm_stat"
    except (OSError, ValueError, AttributeError):
        total = available = 0
        source = "unknown"
    try:
        threads = len(os.sched_getaffinity(0))
    except (AttributeError, OSError):
        threads = os.cpu_count() or 1
    gpu = "cpu"
    if probe_gpu and _output(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"]).strip():
        gpu = "nvidia"
    elif probe_gpu and system == "Linux" and Path("/dev/kfd").exists() and Path("/dev/dri").exists():
        gpu = "amd"
    return Hardware(system, platform.machine(), total, min(total, available), threads, gpu, source)


def plan_local(hardware, daemon_memory=None, cpu_only=False):
    if hardware.total_bytes <= 0 or hardware.available_bytes <= 0:
        raise ValueError("Available RAM could not be measured; a model will not start without a verifiable budget.")
    reserve = max(2 * GB, hardware.total_bytes // 5)
    budget = min(OPERATING_RAM_LIMIT, hardware.total_bytes * 65 // 100,
                 max(0, hardware.available_bytes - reserve))
    if daemon_memory is not None:
        if type(daemon_memory) is not int or daemon_memory <= 0:
            raise ValueError("Available Docker memory is unknown")
        budget = min(budget, daemon_memory * 65 // 100)
    budget = budget // 1_000_000 * 1_000_000
    gpu = "cpu" if cpu_only else hardware.gpu_hint
    candidates = [p for p in PROFILES if p.minimum_budget <= budget
                  and not (gpu == "cpu" and p.model.endswith(":9b"))]
    if not candidates:
        raise ValueError("Not enough free RAM for the smallest profile and system reserve. Close applications or use demo mode.")
    return {"hardware": asdict(hardware), "ram_limit_bytes": budget,
            "absolute_ram_ceiling_bytes": ABSOLUTE_RAM_LIMIT,
            "reserved_host_bytes": reserve, "backend": gpu,
            "threads": min(8, max(1, hardware.cpu_threads // 2)),
            "profiles": [asdict(p) for p in reversed(candidates)],
            "guard_scope": "Model server container RAM; excludes host OS, app/browser, Docker VM overhead and dedicated VRAM"}
