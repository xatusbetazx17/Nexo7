# Start Nexo 7

1. Extract this archive to a folder you own. Keep the included files together.
2. Windows: double-click `Nexo7.exe`. Linux: run `./Nexo7` (or open it in a file manager that supports executable files). If execute permission is missing, run `chmod +x Nexo7` first.
3. Your browser opens the Nexo interface. Keep the application running while you use it.
4. Choose **Check requirements**. Local inference requires a running local Docker engine with Linux containers and cgroups v2. Follow the official Docker links in the setup screen if it is missing. Installing Docker may require OS configuration, permissions and a restart.
5. Choose **Download & start local AI**. Initial image/model downloads can use several GB. Setup verifies the RAM guard and loads a supported model. GPU support is optional; you can select CPU only.
6. When setup finishes, start a conversation. Choose a response language in chat. English and Spanish are supported by the selected base model; quality varies by model and language.
7. Use **Quit Nexo** to close the application and stop its model. Closing the browser tab alone keeps Nexo running. Downloads and your notes are retained for next time. Each launch checks resources again; already downloaded model layers are reused.

**Try it immediately:** choose **Explore demo without a model** for calculations and saved-document lookup. Demo does not generate AI answers.

The portable app includes Python. It does not bundle Docker, GPU drivers or model weights. No API key or paid AI account is required for local mode. Internet is needed for first downloads and PubMed searches; local chat can work offline after its dependencies and model have been downloaded.

Windows builds target x86-64 Windows with a supported Docker Desktop/WSL 2 installation (Docker currently specifies at least 8 GB system RAM). Linux CI builds target x86-64 glibc systems using Ubuntu 22.04; actual compatibility depends on host libraries and Docker support. ARM and 32-bit builds are not provided. Unsigned preview binaries may require normal operating-system trust decisions; no code-signing certificate is bundled.

## Memory and data

The selected model download is checked against a profile cap of 1.5–7.5 decimal GB. Its inference container normally receives at most 12 GB RAM and can never be configured above 16 decimal GB. The launcher reserves room for other applications and refuses to run if the guard cannot be verified. This is not a 16 GB limit on total installation size or whole-computer memory. The OS, browser, app, Docker VM overhead and dedicated GPU VRAM are separate. Model fallback downloads and Docker images can accumulate on disk.

Your notes and chat history are stored locally without encryption: `%LOCALAPPDATA%\Nexo7` on Windows, `$XDG_DATA_HOME/Nexo7` or `~/.local/share/Nexo7` on Linux. Private mode avoids saving a conversation. Saved documents are still searchable in private mode. PubMed receives the topic you search; do not include patient identifiers.

The application is an independent assistant built around an existing model, not official GPT-7. It has no demonstrated superiority to frontier models and is not clinically validated.
